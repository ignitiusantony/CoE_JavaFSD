import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_analytics/firebase_analytics.dart';

class LeaderboardScreen extends StatelessWidget {
  final FirebaseAnalytics analytics = FirebaseAnalytics.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Leaderboard', style: Theme.of(context).textTheme.bodyMedium),
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          // Trigger a refresh (Firestore updates automatically with snapshots)
        },
        child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('game_completions')
              .orderBy('time', descending: false) // Order by time in ascending order
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(
                child: Text('Error: ${snapshot.error}'),
              );
            }
            if (!snapshot.hasData) {
              return Center(child: CircularProgressIndicator());
            }
            final completions = snapshot.data!.docs;
            if (completions.isEmpty) {
              return Center(
                child: Text('No game completions found.'),
              );
            }

            // Log the fetched data for debugging
            print('Fetched game completions data: ${completions.map((doc) => doc.data()).toList()}');

            // Sort completions by difficulty: Hard > Medium > Easy
            final sortedCompletions = completions..sort((a, b) {
              final dataA = a.data() as Map<String, dynamic>;
              final dataB = b.data() as Map<String, dynamic>;
              final difficultyOrder = {'Hard': 1, 'Medium': 2, 'Easy': 3};
              final difficultyA = difficultyOrder[dataA['difficulty']] ?? 4;
              final difficultyB = difficultyOrder[dataB['difficulty']] ?? 4;
              return difficultyA.compareTo(difficultyB);
            });

            return ListView.builder(
              itemCount: sortedCompletions.length,
              itemBuilder: (context, index) {
                final entry = sortedCompletions[index];
                final data = entry.data() as Map<String, dynamic>; // Cast to Map<String, dynamic>
                final username = data.containsKey('username') ? data['username'] : 'Unknown';
                final time = data.containsKey('time') ? data['time'] : 'N/A';
                final difficulty = data.containsKey('difficulty') ? data['difficulty'] : 'Unknown';

                return Card(
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Text('${index + 1}'),
                    ),
                    title: Text(username),
                    subtitle: Text('Difficulty: $difficulty | Time: $time seconds'),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
