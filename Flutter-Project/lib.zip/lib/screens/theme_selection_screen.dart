import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

class ThemeSelectionScreen extends StatelessWidget {
  final String userId;

  ThemeSelectionScreen({required this.userId});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text('Select Theme')),
      body: AnimatedSwitcher(
        duration: Duration(milliseconds: 300),
        child: ListView(
          key: ValueKey(themeProvider.themeName),
          children: [
            _buildThemeButton(context, 'Light', ThemeData.light()),
            _buildThemeButton(context, 'Dark', ThemeData.dark()),
            _buildThemeButton(context, 'Retro Arcade', themeProvider.retroArcadeTheme),
            _buildThemeButton(context, 'Nature Explorer', themeProvider.natureExplorerTheme),
            _buildThemeButton(context, 'Classic', themeProvider.classicTheme),
          ],
        ),
      ),
    );
  }

  Widget _buildThemeButton(BuildContext context, String themeName, ThemeData themeData) {
    final themeProvider = Provider.of<ThemeProvider>(context, listen: false);

    return ListTile(
      title: Text(themeName),
      onTap: () async {
        themeProvider.setTheme(themeName, themeData);
        await themeProvider.saveThemeToFirestore(userId);
      },
    );
  }
}
