import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'leaderboard_screen.dart'; // Import the LeaderboardScreen

class ScoresScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Scores & Statistics'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LeaderboardScreen()),
                );
              },
              child: Text('View Leaderboard'),
            ),
            SizedBox(height: 16),
            Text(
              'Highest Scores',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('highest_scores')
                    .orderBy('time')
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(child: CircularProgressIndicator());
                  }
                  final scores = snapshot.data!.docs;
                  return ListView.builder(
                    itemCount: scores.length,
                    itemBuilder: (context, index) {
                      final score = scores[index];
                      return ListTile(
                        title: Text('Difficulty: ${score['difficulty']}'),
                        subtitle: Text('Time: ${score['time']} seconds'),
                      );
                    },
                  );
                },
              ),
            ),
            SizedBox(height: 16),
            Text(
              'Game Completions',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('game_completions')
                    .orderBy('time', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(child: CircularProgressIndicator());
                  }
                  final completions = snapshot.data!.docs;
                  return ListView.builder(
                    itemCount: completions.length,
                    itemBuilder: (context, index) {
                      final completion = completions[index];
                      return ListTile(
                        title: Text(
                            'Difficulty: ${completion['difficulty']} | Time: ${completion['time']} seconds'),
                        subtitle: Text(
                            'Attempts: ${completion['attempts']} | Matched Pairs: ${completion['matchedPairs']}'),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
