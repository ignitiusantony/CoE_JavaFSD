import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:memory_master/screens/memory_master_game.dart';

class DifficultyScreen extends StatelessWidget {
  Future<int?> fetchHighestScore(String difficulty) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('highest_scores')
          .doc(difficulty)
          .get();

      if (snapshot.exists && snapshot.data() != null) {
        return snapshot.data()?['time'];
      }
    } catch (e) {
      print('Error fetching high score for $difficulty: $e');
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Memory Master'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildDifficultyButton(context, 'Easy', 8),
            SizedBox(height: 20),
            _buildDifficultyButton(context, 'Medium', 12),
            SizedBox(height: 20),
            _buildDifficultyButton(context, 'Hard', 16),
          ],
        ),
      ),
    );
  }

  Widget _buildDifficultyButton(BuildContext context, String label, int cardCount) {
    return FutureBuilder<int?>(
      future: fetchHighestScore(label),
      builder: (context, snapshot) {
        String highestScoreText = 'Loading...';

        if (snapshot.connectionState == ConnectionState.done) {
          if (snapshot.hasError) {
            highestScoreText = 'Error fetching score';
          } else if (snapshot.data != null) {
            highestScoreText = 'Best Time: ${snapshot.data}s';
          } else {
            highestScoreText = 'No score yet';
          }
        }

        return Column(
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MemoryMasterGame(difficulty: cardCount),
                  ),
                );
              },
              child: Text(label),
              style: ElevatedButton.styleFrom(
                minimumSize: Size(200, 60),
              ),
            ),
            SizedBox(height: 8),
            Text(
              highestScoreText,
              style: TextStyle(fontSize: 14, color: Colors.black),
              textAlign: TextAlign.center,
            ),
          ],
        );
      },
    );
  }
}
