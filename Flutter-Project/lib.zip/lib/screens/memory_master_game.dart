import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/word_service.dart';
import '../models/game_card.dart';

class MemoryMasterGame extends StatefulWidget {
  final int difficulty;

  const MemoryMasterGame({Key? key, this.difficulty = 8}) : super(key: key);

  @override
  _MemoryMasterGameState createState() => _MemoryMasterGameState();
}

class _MemoryMasterGameState extends State<MemoryMasterGame> {
  final WordService _wordService = WordService();
  late GameLogic _gameLogic;
  bool _isLoading = true;
  String? _matchedWordMeaning; // Add state variable for matched word meaning

  @override
  void initState() {
    super.initState();
    _initializeGame();
  }

  void _initializeGame() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final words = await _wordService.fetchRandomWords(widget.difficulty ~/ 2);
      setState(() {
        _gameLogic = GameLogic();
        _gameLogic.initializeCards(words);
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showErrorDialog('Failed to load game data. Please try again.');
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text(message),
          actions: [
            TextButton(
              child: Text('Retry'),
              onPressed: () {
                Navigator.of(context).pop();
                _initializeGame();
              },
            ),
          ],
        );
      },
    );
  }

  void _handleCardTap(int index) async {
    setState(() {
      _gameLogic.selectCard(index);
    });

    if (_gameLogic.isGameComplete()) {
      _saveGameCompletion();
      _showCompletionDialog();
    } else if (_gameLogic.isLastMatchSuccessful()) {
      final matchedWord = _gameLogic.getLastMatchedWord();
      if (matchedWord != null) {
        try {
          final meaning = await _wordService.fetchWordMeaning(matchedWord);
          setState(() {
            _matchedWordMeaning = meaning;
          });
        } catch (e) {
          setState(() {
            _matchedWordMeaning = 'Meaning not available.'; // Fixed syntax
          });
        }
      }
    }
  }

  Future<void> _saveGameCompletion() async {
    await FirebaseFirestore.instance.collection('game_completions').add({
      'difficulty': widget.difficulty,
      'attempts': _gameLogic.attempts,
      'matchedPairs': _gameLogic.matchedPairs,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  void _showCompletionDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Congratulations!'),
          content: Text('You completed the game in ${_gameLogic.attempts} attempts.'),
          actions: [
            TextButton(
              child: Text('Play Again'),
              onPressed: () {
                Navigator.of(context).pop();
                _initializeGame();
              },
            )
          ],
        );
      },
    );
  }

  void _activateRevealPair() {
    setState(() {
      _gameLogic.revealRandomPair();
    });
    _savePowerUpUsage('Reveal Pair');
  }

  void _activateFreezeTime() {
    setState(() {
      _gameLogic.freezeTime();
    });
    _savePowerUpUsage('Freeze Time');
  }

  Future<void> _savePowerUpUsage(String powerUpName) async {
    await FirebaseFirestore.instance.collection('power_up_usage').add({
      'powerUp': powerUpName,
      'difficulty': widget.difficulty,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (_gameLogic.cards.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: Text('Memory Master'),
        ),
        body: Center(
          child: Text(
            'No cards available. Please try again.',
            style: TextStyle(fontSize: 18),
          ),
        ),
      );
    }

    return GestureDetector(
      onDoubleTap: _activateRevealPair,
      onVerticalDragEnd: (details) {
        if (details.primaryVelocity != null && details.primaryVelocity! < 0) {
          _activateFreezeTime();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text('Memory Master'),
          actions: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(child: Text('Attempts: ${_gameLogic.attempts}')),
            ),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: GridView.builder(
                padding: EdgeInsets.all(8),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  childAspectRatio: 0.7,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                itemCount: _gameLogic.cards.length,
                itemBuilder: (context, index) {
                  final card = _gameLogic.cards[index];
                  return GestureDetector(
                    onTap: () => _handleCardTap(index),
                    child: Card(
                      color: card.isMatched
                          ? Colors.green.shade200
                          : card.isRevealed
                              ? Colors.blue.shade200
                              : Colors.grey.shade300,
                      child: Center(
                        child: card.isRevealed || card.isMatched
                            ? Text(
                                card.word,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              )
                            : Icon(Icons.help_outline),
                      ),
                    ),
                  );
                },
              ),
            ),
            if (_matchedWordMeaning != null) // Display matched word meaning
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Meaning: $_matchedWordMeaning',
                  style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
                  textAlign: TextAlign.center,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
