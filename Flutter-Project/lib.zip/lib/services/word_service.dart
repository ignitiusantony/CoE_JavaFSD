import 'dart:convert';
import 'package:http/http.dart' as http;

class WordService {
  static const String randomWordApiUrl = 'https://random-word-api.herokuapp.com/word';
  static const String dictionaryApiUrl = 'https://api.dictionaryapi.dev/api/v2/entries/en';

  Future<List<String>> fetchRandomWords(int count) async {
    try {
      final response = await http.get(
        Uri.parse('$randomWordApiUrl?number=$count'),
      );

      if (response.statusCode == 200) {
        List<dynamic> words = json.decode(response.body);
        return words.map((word) => word.toString()).toList();
      } else {
        throw Exception('Failed to load words');
      }
    } catch (e) {
      // Fallback words if API fails
      return [
        'apple', 'banana', 'cat', 'dog', 
        'elephant', 'frog', 'guitar', 'house',
        'island', 'jungle', 'kite', 'lion'
      ].take(count).toList();
    }
  }

  Future<String> fetchWordMeaning(String word) async {
    try {
      final response = await http.get(
        Uri.parse('$dictionaryApiUrl/$word'),
      );

      if (response.statusCode == 200) {
        List<dynamic> meaningData = json.decode(response.body);
        
        // Extract meaning
        if (meaningData.isNotEmpty && 
            meaningData[0]['meanings'] is List) {
          List meanings = meaningData[0]['meanings'];
          
          // Compile a readable meaning string
          StringBuffer meaningBuffer = StringBuffer();
          
          for (var meaning in meanings) {
            String partOfSpeech = meaning['partOfSpeech'] ?? 'Unknown';
            List definitions = meaning['definitions'] ?? [];
            
            meaningBuffer.writeln('$partOfSpeech:');
            
            for (var def in definitions.take(2)) {
              meaningBuffer.writeln('- ${def['definition']}');
            }
            meaningBuffer.writeln();
          }
          
          return meaningBuffer.toString().trim();
        }
        
        return 'No meaning found for $word';
      } else {
        return 'Unable to fetch meaning for $word';
      }
    } catch (e) {
      return 'Error fetching meaning: ${e.toString()}';
    }
  }

  Future<Map<String, String>> fetchWordsMeanings(List<String> words) async {
    Map<String, String> wordMeanings = {};
    
    for (String word in words) {
      String meaning = await fetchWordMeaning(word);
      wordMeanings[word] = meaning;
    }
    
    return wordMeanings;
  }
}
