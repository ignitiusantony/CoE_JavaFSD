import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';

class GameCard {
  final String word;
  bool isMatched;
  bool isRevealed;

  GameCard({
    required this.word, 
    this.isMatched = false, 
    this.isRevealed = false
  });

  void reset() {
    isMatched = false;
    isRevealed = false;
  }
}

class GameLogic {
  List<GameCard> cards = [];
  int? firstSelectedIndex;
  int attempts = 0;
  int matchedPairs = 0;

  void initializeCards(List<String> words) {
    // Duplicate words to create pairs
    final fullWordList = [...words, ...words];
    fullWordList.shuffle();

    cards = fullWordList.map((word) => GameCard(word: word)).toList();
  }

  bool selectCard(int index) {
    if (cards[index].isMatched || cards[index].isRevealed) return false;

    cards[index].isRevealed = true;
    attempts++;

    if (firstSelectedIndex == null) {
      firstSelectedIndex = index;
      return true;
    }

    // Check for match
    if (cards[firstSelectedIndex!].word == cards[index].word) {
      cards[firstSelectedIndex!].isMatched = true;
      cards[index].isMatched = true;
      matchedPairs++;
      firstSelectedIndex = null;
      return true;
    }

    // No match - reset after a short delay
    Future.delayed(Duration(seconds: 1), () {
      cards[firstSelectedIndex!].isRevealed = false;
      cards[index].isRevealed = false;
      firstSelectedIndex = null;
    });

    return false;
  }

  bool isGameComplete() {
    return matchedPairs == cards.length ~/ 2;
  }

  Future<void> saveGameStats(String difficulty) async {
    await FirebaseFirestore.instance.collection('game_stats').add({
      'difficulty': difficulty,
      'attempts': attempts,
      'matchedPairs': matchedPairs,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  void resetGame() {
    // Save stats before resetting
    saveGameStats('current_difficulty'); // Replace with actual difficulty
    attempts = 0;
    matchedPairs = 0;
    firstSelectedIndex = null;
    cards.forEach((card) => card.reset());
  }

  void revealRandomPair() {
    // Find all unmatched and unrevealed cards
    final unmatchedCards = cards.where((card) => !card.isMatched && !card.isRevealed).toList();

    if (unmatchedCards.length >= 2) {
      // Shuffle the list to randomize the selection
      unmatchedCards.shuffle();

      // Reveal the first two cards
      unmatchedCards[0].isRevealed = true;
      unmatchedCards[1].isRevealed = true;

      print('Revealed cards: ${unmatchedCards[0].word}, ${unmatchedCards[1].word}');

      // Flip the cards back after a short delay
      Future.delayed(Duration(seconds: 2), () {
        unmatchedCards[0].isRevealed = false;
        unmatchedCards[1].isRevealed = false;
        print('Flipped cards back: ${unmatchedCards[0].word}, ${unmatchedCards[1].word}');
      });
    } else {
      print('Not enough cards to reveal a pair.');
    }
  }

  void freezeTime() {
    // Simulate freezing the game timer by pausing for a short duration
    print('Freezing the game timer for 3 seconds...');
    Future.delayed(Duration(seconds: 3), () {
      print('Game timer resumed.');
    });
  }

  bool isLastMatchSuccessful() {
    // Implement logic to check if the last match was successful
    return true; // Placeholder
  }

  String? getLastMatchedWord() {
    // Implement logic to return the last matched word
    return "example"; // Placeholder
  }
}
