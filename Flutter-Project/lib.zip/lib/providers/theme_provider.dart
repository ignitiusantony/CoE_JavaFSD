import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeData _themeData = ThemeData.light();
  String _themeName = 'Light';

  ThemeData get themeData => _themeData;
  String get themeName => _themeName;

  void setTheme(String themeName, ThemeData themeData) {
    _themeName = themeName;
    _themeData = themeData;
    notifyListeners();
  }

  Future<void> loadThemeFromFirestore(String userId) async {
    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(userId).get();
      if (doc.exists && doc.data()?['theme'] != null) {
        final themeName = doc.data()?['theme'];
        switch (themeName) {
          case 'Classic':
            setTheme('Classic', _classicTheme());
            break;
          case 'Dark':
            setTheme('Dark', ThemeData.dark());
            break;
          case 'Retro Arcade':
            setTheme('Retro Arcade', _retroArcadeTheme());
            break;
          case 'Nature Explorer':
            setTheme('Nature Explorer', _natureExplorerTheme());
            break;
          default:
            setTheme('Light', ThemeData.light());
        }
      }
    } catch (e) {
      print('Error loading theme: $e');
    }
  }

  Future<void> saveThemeToFirestore(String userId) async {
    try {
      await FirebaseFirestore.instance.collection('users').doc(userId).set({'theme': _themeName});
    } catch (e) {
      print('Error saving theme: $e');
    }
  }

  ThemeData get retroArcadeTheme => _retroArcadeTheme();
  ThemeData get natureExplorerTheme => _natureExplorerTheme();
  ThemeData get classicTheme => _classicTheme();

  ThemeData _retroArcadeTheme() {
    return ThemeData(
      primarySwatch: Colors.purple,
      scaffoldBackgroundColor: Colors.black,
      textTheme: TextTheme(bodyMedium: TextStyle(color: Colors.greenAccent)),
    );
  }

  ThemeData _natureExplorerTheme() {
    return ThemeData(
      primarySwatch: Colors.green,
      scaffoldBackgroundColor: Colors.brown[100],
      textTheme: TextTheme(bodyMedium: TextStyle(color: Colors.brown)),
    );
  }

  ThemeData _classicTheme() {
    return ThemeData(
      primarySwatch: Colors.blueGrey,
      scaffoldBackgroundColor: Color(0xFFF5F5DC), // Beige color
      textTheme: TextTheme(
        bodyMedium: TextStyle(
          fontFamily: 'Times New Roman',
          fontSize: 16,
          color: Colors.black,
        ),
      ),
    );
  }
}
