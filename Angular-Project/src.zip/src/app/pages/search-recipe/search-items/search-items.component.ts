import { Component, Input } from '@angular/core';
import { Recipe } from '../../../models/recipe';

@Component({
  selector: 'app-search-items',
  templateUrl: './search-items.component.html',
  styleUrl: './search-items.component.css'
})
export class SearchItemsComponent {
@Input() recipe: Recipe = {
  name: '',
  ingredients: [],
  steps: [],
  image: '',
  bgColor: undefined,
  description: ''
}
}
