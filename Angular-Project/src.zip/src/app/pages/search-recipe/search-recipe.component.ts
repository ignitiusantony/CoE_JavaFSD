import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router'; // Adjust the path if necessary
import { ApiServicesService } from '../../services/api-services.service';
import { Recipe } from '../../models/recipe';

@Component({
  selector: 'app-search-recipe',
  templateUrl: './search-recipe.component.html',
  styleUrl: './search-recipe.component.css'
})
export class SearchRecipeComponent {
  recipelist: Recipe[] = [];
  recipenames: string[] = [
    "Croissants",
    "Danish Pastries",
    "Eclairs",
    "Choux Pastry (Profiteroles)",
    "Apple Turnovers",
    "Pain au Chocolat",
    "Palmier",
    "Mille-Feuille (Napoleon Pastry)",
    "Tarts (Mini Fruit Tarts)",
    "Madeleines"
  ];
  selected: string='Croissants';
  constructor(private as:ApiServicesService) { }
  ngOnInit(): void {
    this.as.getRecipe().subscribe({
        next:(result:Recipe[])=>{this.recipelist=result},
        error:(err:any)=>{console.log(err)}
    })
  }
}