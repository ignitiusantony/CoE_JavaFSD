import { Component } from '@angular/core';// Import the API service
import { ApiServicesService } from '../../services/api-services.service';
import {IngredientData} from '../../models/ingredients';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrl: './list.component.css'
})

export class ListComponent {

  constructor(private apiService: ApiServicesService) {} 

   // Store names and ingredients
  ingredientsList: { name: string; ingredients: any[] }[] = [];
  ngOnInit(): void {
    this.apiService.getIngredient().subscribe(
      (data: IngredientData[]) => {
        this.ingredientsList = data.map((item) => ({
          name: item.name,
          ingredients: item.ingredients ?? [] 
        }));
        console.log('Fetched Ingredients List:', this.ingredientsList);
      },
      (error) => {
        console.error('Error fetching ingredients list:', error);
      }
    );    
  }
}
