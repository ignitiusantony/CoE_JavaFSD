import { Component, ElementRef, Input, Renderer2 } from '@angular/core';
import { Recipe } from '../../../models/recipe';
import { ApiServicesService } from '../../../services/api-services.service';

@Component({
  selector: 'app-recipy',
  templateUrl: './recipy.component.html',
  styleUrl: './recipy.component.css'
})
export class RecipyComponent {
@Input() recipe: Recipe = {
  name: '',
  ingredients: [],
  steps: [],
  image: '',
  bgColor: undefined,
  description: ''
}
showDetails: boolean = false; // Initially hidden

constructor(private api: ApiServicesService) {}

toggleDetails() {
  this.showDetails = !this.showDetails; // Toggle visibility
}

addToIngredientList() {
  if (this.recipe.name && this.recipe.ingredients.length > 0) {
    this.api.addIngredient({
      name: this.recipe.name,
      ingredients: this.recipe.ingredients
    }).subscribe(response => {
      console.log('Ingredient added successfully:', response);
    }, error => {
      console.error('Error adding ingredient:', error);
    });
  }
}
}
