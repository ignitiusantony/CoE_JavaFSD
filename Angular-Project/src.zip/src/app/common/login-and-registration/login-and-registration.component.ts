import { Component} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiServicesService } from '../../services/api-services.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-and-registration',
  templateUrl: './login-and-registration.component.html',
  styleUrls: ['./login-and-registration.component.css']
})
export class LoginAndRegistrationComponent {
  loginForm: FormGroup;
  registerForm: FormGroup;
  errors: string[] = [];
  isRegisterMode = false; 

  constructor(private fb: FormBuilder, private authService: ApiServicesService, private router: Router) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });

    this.registerForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]]
    });
  }

  toggleForm(event: Event) {
    this.isRegisterMode = (event.target as HTMLInputElement).checked;
  }

  login() {
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.value).subscribe({
        next: (user) => {
          if (user.length) {
            localStorage.setItem('user', JSON.stringify(user[0]));
            const storedUser = localStorage.getItem('user');
            if (storedUser) {
              this.router.navigate(['/recipes']).then(navigated => {
                if (!navigated) {
                  alert('Navigation to recipes failed.');
                }
              });
            } else {
              alert('Failed to store user data in localStorage.');
            }
          } else {
            alert('Invalid credentials!');
          }
        },
        error: () => {
          alert('An error occurred during login. Please try again.');
        }
      });
    }
  }

  submitForm() {
    this.errors = [];
    let emailPattern = /^[a-zA-Z0-9._]+@[a-zA-Z]+\.[a-zA-Z]{2,4}$/;

    let { name, email, password, confirmPassword } = this.registerForm.value;

    if (!name || name.length < 3) this.errors.push("Name should be at least three characters long");
    if (!email || !emailPattern.test(email)) this.errors.push("Invalid Email");
    if (!password || password.length < 6) this.errors.push("Password should be at least 6 characters long");
    if (password !== confirmPassword) this.errors.push("Passwords do not match");

    if (this.errors.length === 0) {
      this.authService.register({ name, email, password }).subscribe({
        next: () => {
          alert("Registration Successful! Please log in.");
          this.registerForm.reset(); // Switch back to login
        },
        error: () => {
          alert("Something went wrong. Please try again.");
        }
      });
    }
  }
}
