import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiServicesService {
  private apiUrl = 'http://localhost:3000/users';

  constructor(private http: HttpClient) { }

  register(user: any): Observable<any> {
    return this.http.post(this.apiUrl, user);
  }

  login(credentials: any): Observable<any> {
    return this.http.get<any[]>(`${this.apiUrl}?email=${credentials.email}&password=${credentials.password}`);
  }

  isAuthenticated(): boolean {
    return localStorage.getItem('user') !== null;
  }
  getRecipe(): Observable<any> {
    return this.http.get('http://localhost:3000/recipes');
  }

  addIngredient(ingredient: any): Observable<any> {
    return this.http.post('http://localhost:3000/ingredients-list', ingredient);
  }

  getIngredient(): Observable<any> {
    return this.http.get('http://localhost:3000/ingredients-list');
  }

}
