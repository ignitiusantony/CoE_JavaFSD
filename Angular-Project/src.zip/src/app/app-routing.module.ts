import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { loginGuard } from './gaurd/login.guard';
import { LoginAndRegistrationComponent } from './common/login-and-registration/login-and-registration.component';
import { RecipesComponent } from './pages/recipes/recipes.component';
import { SearchRecipeComponent } from './pages/search-recipe/search-recipe.component';
import { ListComponent } from './pages/list/list.component';

const routes: Routes = [
  {path: '', component:LoginAndRegistrationComponent},
  {path: 'recipes', component:RecipesComponent, canActivate:[loginGuard]},
  {path: 'search-recipe', component:SearchRecipeComponent, canActivate:[loginGuard]},
  {path: 'list', component:ListComponent, canActivate:[loginGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
